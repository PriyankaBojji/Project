package com.capgemini.bank.ui;

public class Client {

	public static void main (String[] args) {
		
		
		
		
		
	}
}
