package com.capgemini.bank.bean;

import java.sql.Date;
import java.time.LocalDate;

public class DemandDraft {
	private static int transaction_id;
	private static String customer_name;
	private static String in_favor_of;
	private static String phone_number;
	private static Date date_of_transaction;
	private static int dd_amount;
	private static int dd_commission;
	
	
	public static int getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}
	public static String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public static String getIn_favor_of() {
		return in_favor_of;
	}
	public void setIn_favor_of(String in_favor_of) {
		this.in_favor_of = in_favor_of;
	}
	public static String getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}
	
	public static Date getDate_of_transaction() {
		return date_of_transaction;
	}
	public void setDate_of_transaction(Date date_of_transaction) {
		this.date_of_transaction = date_of_transaction;
	}
	public static int getDd_amount() {
		return dd_amount;
	}
	public void setDd_amount(int dd_amount) {
		this.dd_amount = dd_amount;
	}
	public static int getDd_commission() {
		return dd_commission;
	}
	public void setDd_commission(int dd_commission) {
		this.dd_commission = dd_commission;
	}
	
	/*public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Printing Details \n");
		sb.append("Transaction ID: " +transaction_id +"\n"); 
		sb.append("Name: " +customer_name +"\n");
		sb.append("In favor of " +in_favor_of +"\n");
		sb.append("Phone Number: "+phone_number +"\n");
		sb.append("Date of transaction: "+date_of_transaction +"\n");
		sb.append("DD Amount" +dd_amount +"\n");
		sb.append("DD Commission" +dd_commission +"\n");
		return sb.toString();
	}
	*/
	
	

}
