package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.exception.DraftException;

public class DemandDraftService implements IDemandDraftService{
	
		public String addDemandDraftDetails(DemandDraft demanddraft) throws DraftException {
			
			DemandDraftDAO = new DemandDraftDAO();
			int Transaction_Id_Seq;
			Transaction_Id_Seq= DemandDraftDAO.addDemandDraftDetails(demanddraft);
			return Transaction_Id_Seq;
		}
		
	}
	
	public DemandDraft getDemandDraftDetails(int transactionId) {
		
	}

}
