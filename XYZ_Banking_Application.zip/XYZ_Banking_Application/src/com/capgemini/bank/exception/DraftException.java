package com.capgemini.bank.exception;

public class DraftException extends Exception {

        /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		public DraftException(String msg){
        	super(msg);
        }
}
