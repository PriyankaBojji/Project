package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DraftException;


public class DemandDraftDAO implements IDemandDraftDAO {

	
	
	public int addDemandDraftDetails(DemandDraft demandDraft){
    Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String patient_id=null;
		
		int queryResult=0;
		try
		{	
			
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			
			preparedStatement.setInt(1, DemandDraft.getTransaction_id());
			preparedStatement.setString(2, DemandDraft.getCustomer_name());
			preparedStatement.setString(3, DemandDraft.getIn_favor_of());
			preparedStatement.setString(4, DemandDraft.getPhone_number());
			preparedStatement.setDate(5, DemandDraft.getDate_of_transaction());
			preparedStatement.setInt(6, DemandDraft.getDd_amount());
			preparedStatement.setInt(7, DemandDraft.getDd_commission());
			
				
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.Transaction_Id_Sequence);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				transaction_id = resultSet.getInt(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new DraftException("Inserting Patient details failed ");

			}
			else
			{
				logger.info("Patient details added successfully:");
				return transaction_id;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new DraftException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new DraftException("Error in closing db connection");

			}
		}
		
		
	}
	
	public DemandDraft getDemandDraftDetails(int transactionId) {
		
		
	}
}
