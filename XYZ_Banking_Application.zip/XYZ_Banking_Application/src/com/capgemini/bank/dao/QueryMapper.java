package com.capgemini.bank.dao;

public interface QueryMapper {
	public static final String INSERT_QUERY="INSERT INTO demand_draft VALUES(Transaction_Id_Seq.NEXTVAL,?,?,?,(select SYSDATE from DUAL),?,?,? )";
	public static final String Transaction_Id_Sequence="SELECT Transaction_Id_Seq.CURRVAL FROM DUAL";

}
