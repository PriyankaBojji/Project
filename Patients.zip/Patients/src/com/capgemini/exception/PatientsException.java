package com.capgemini.exception;

public class PatientsException extends Exception {
private static final long serialVersionUID = 726264577455921591L;
	public PatientsException(String message) 
	{
		
		super(message);
	}

}
